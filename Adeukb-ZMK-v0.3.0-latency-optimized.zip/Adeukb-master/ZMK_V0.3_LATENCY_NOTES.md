# ZMK v0.3 migration and Bluetooth latency notes

## Version migration

This configuration is pinned to ZMK `v0.3.0` in both:
- `config/west.yml`
- `.github/workflows/build.yml`

The `zmk-nice-oled` module remains on `main`; its upstream documentation states that the current module is tested with ZMK v0.3.0.

## Latency-related changes

- `CONFIG_ZMK_BLE_EXPERIMENTAL_CONN=n`
  - The experimental connection setting disables the Bluetooth 2M PHY.
  - Leaving it disabled allows the nRF52840 to negotiate 2M PHY when supported by the host.
  - If a particular host has Bluetooth compatibility problems, this can be changed back to `y`.

- `CONFIG_ZMK_SPLIT_BLE_PREF_LATENCY=0`
  - The ZMK split BLE default is 30.
  - This configuration favors responsiveness between the two Sofle halves over battery life by requesting zero slave/peripheral latency.

## Things intentionally left unchanged

- `CONFIG_BT_CTLR_TX_PWR_PLUS_8=y`: increases radio transmit power; this is not inherently a latency penalty and may improve reliability.
- `CONFIG_EC11_TRIGGER_GLOBAL_THREAD=y`: affects encoder processing, not normal key scanning.
- OLED/nice-oled remains enabled. Its documented default display thread priority is 5; the nice-oled project specifically warns that priorities 1 or 2 can interfere with typing latency. No such aggressive priority is configured here.
- RGB underglow uses ZMK's low-priority work queue and is not configured as a high-priority workload.

## Important latency floor

This is a wireless split Sofle. ZMK documents that the BLE split transport itself adds about 3.75 ms average and up to 7.5 ms worst-case to the input path. That portion cannot be eliminated while retaining the standard BLE split transport.
